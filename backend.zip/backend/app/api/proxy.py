import asyncio
import aiohttp
import json
import time
import logging
from typing import Optional, Union
from aiohttp import ClientConnectionError
from fastapi import APIRouter, Request, HTTPException, Depends
from fastapi.responses import StreamingResponse, JSONResponse
from fastapi.background import BackgroundTasks
from sqlalchemy import select, update, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.engine import Engine
from app.db.session import get_db
from app.db.redis import get_redis
from app.models.models import ApiKey, User, UserModel, QaRecord
from app.core.utils import now
from app.core.config import get_settings

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s %(levelname)s [%(name)s] %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

router = APIRouter()


def parse_authorization(auth_header: Optional[str]) -> Optional[str]:
    if not auth_header:
        return None
    if auth_header.startswith("Bearer "):
        return auth_header[7:]
    return auth_header


def _get_client_ip(request: Request) -> str:
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "0.0.0.0"


def _check_ip_whitelist(allowed_ips: Optional[str], client_ip: str) -> bool:
    if not allowed_ips or not allowed_ips.strip():
        return True
    ip_list = [ip.strip() for ip in allowed_ips.split(",") if ip.strip()]
    if not ip_list:
        return True
    return client_ip in ip_list


async def get_user_by_api_key(api_key: str, db: AsyncSession, request: Optional[Request] = None):
    client_ip = _get_client_ip(request) if request else ""
    result = await db.execute(
        select(ApiKey).where(
            ApiKey.key == api_key,
            ApiKey.status == "active",
        )
    )
    api_key_obj = result.scalar_one_or_none()
    if not api_key_obj:
        return None, None

    # 检查过期时间
    if api_key_obj.expires_at and api_key_obj.expires_at < now():
        await db.execute(
            update(ApiKey).where(ApiKey.id == api_key_obj.id).values(status="expired")
        )
        await db.commit()
        return None, None

    result = await db.execute(select(User).where(User.id == api_key_obj.user_id))
    user = result.scalar_one_or_none()
    if not user:
        return None, None

    if user.status != "active":
        return None, None

    # IP 白名单检查
    if request and client_ip:
        if not _check_ip_whitelist(user.allowed_ips, client_ip):
            logger.warning(f"IP {client_ip} not in whitelist for user {user.username}")
            return None, None

    # 异步更新 last_used_at，减少事务开销
    api_key_obj.last_used_at = now()
    await db.commit()

    return user, api_key_obj


async def _get_user_models_from_cache(user_id: int, db: AsyncSession):
    """从 Redis 缓存获取用户模型 id 列表，未命中时查询数据库并缓存。

    返回 SQLAlchemy ORM 对象（保证 model_name/api_url/api_key 属性始终可用）。
    """
    cache_key = f"user_models:{user_id}"
    try:
        redis = await get_redis()
        cached = await redis.get(cache_key)
        if cached:
            model_ids = json.loads(cached)
            if isinstance(model_ids, list):
                result = await db.execute(
                    select(UserModel).where(
                        UserModel.user_id == user_id,
                        UserModel.status == "active",
                        UserModel.id.in_(model_ids),
                    ),
                )
                return result.scalars().all()
            else:
                # 兼容旧格式（dict 列表）
                pass
    except Exception:
        pass  # Redis 不可用则忽略

    # 缓存未命中，查库
    result = await db.execute(
        select(UserModel).where(
            UserModel.user_id == user_id,
            UserModel.status == "active",
        )
    )
    models = result.scalars().all()

    # 写缓存（仅存 id，避免 api_key 泄露到缓存）
    try:
        redis = await get_redis()
        await redis.set(
            cache_key,
            json.dumps([m.id for m in models]),  # type: ignore[attr-defined]
            ex=180,  # 3 分钟过期
        )
    except Exception:
        pass  # 缓存写入失败不影响主流程

    return models


async def _save_qa_record(
    user_id: int,
    api_key_id: Optional[int],
    target_model: str,
    method: str,
    request_body: str,
    response_body: str,
    upstream_status: int,
    request_tokens: Optional[int],
    response_tokens: Optional[int],
    total_tokens: int,
    latency_ms: int,
    status: str,
    client_ip: str,
):
    """异步保存 Q&A 记录到数据库（非阻塞，使用新 session 避免 session 生命周期问题）。"""
    logger.info(f"[QA Save] user_id={user_id}, model={target_model}, status={status}")
    from app.db.session import async_session
    try:
        async with async_session() as session:
            record = QaRecord(
                user_id=user_id,
                api_key_id=api_key_id,
                target_model=target_model,
                method=method,
                request_body=request_body,
                response_body=response_body,
                upstream_status=upstream_status,
                request_tokens=request_tokens,
                response_tokens=response_tokens,
                total_tokens=total_tokens,
                latency_ms=latency_ms,
                status=status,
                client_ip=client_ip or None,
            )
            session.add(record)
            await session.commit()
    except Exception:
        logger.error("Failed to save QA record", exc_info=True)


def _extract_tokens(data: dict) -> tuple:
    """从响应数据中提取 token 用量。"""
    usage = data.get("usage", {})
    return (
        usage.get("prompt_tokens"),
        usage.get("completion_tokens"),
        usage.get("total_tokens"),
    )


def _extract_stream_tokens(sse_text: str) -> tuple:
    """从流式响应文本中提取 token 用量。

    在 OpenAI 兼容接口中，最后一条 SSE 数据行通常包含 "usage" 字段，
    其中记录完整的 token 用量。
    """
    for line in sse_text.strip().split("\n"):
        line = line.strip()
        if not line or line.startswith("data: [DONE]") or line == "[DONE]":
            continue
        if line.startswith("data:"):
            line = line[5:].strip()
        if not line:
            continue
        try:
            data = json.loads(line)
            # Check both top-level usage and choices[*].usage
            usage = data.get("usage") or (
                data.get("choices") and data["choices"][-1].get("usage")
            )
            if usage and isinstance(usage, dict):
                return (
                    usage.get("prompt_tokens"),
                    usage.get("completion_tokens"),
                    usage.get("total_tokens"),
                )
        except (json.JSONDecodeError, TypeError):
            pass
    return None, None, None


@router.api_route("/v1/chat/completions", methods=["GET", "POST"])
async def proxy_chat(request: Request, db: AsyncSession = Depends(get_db)):
    auth_header = request.headers.get("authorization")
    api_key = parse_authorization(auth_header)

    if not api_key:
        raise HTTPException(status_code=401, detail="Missing API key")

    user, key_obj = await get_user_by_api_key(api_key, db, request)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or revoked API key")

    models = await _get_user_models_from_cache(user.id, db)
    if not models:
        raise HTTPException(status_code=403, detail="No models bound to this account")

    body = await request.body()
    request_data = json.loads(body) if body else {}
    is_stream = request_data.get("stream", False)

    target_model = request_data.get("model", models[0].model_name)

    target = None
    for m in models:
        if m.model_name == target_model:
            target = m
            break
        if target_model.isdigit() and m.id == int(target_model):
            target = m
            break
    if not target:
        target = models[0]

    base_url = target.api_url.rstrip('/')
    target_url = f"{base_url}/chat/completions"
    headers = {
        "Authorization": f"Bearer {target.api_key}",
        "Content-Type": "application/json",
    }

    for header in ["user-agent", "accept", "accept-encoding"]:
        if request.headers.get(header):
            headers[header] = request.headers[header]

    # Record start time
    start_time = time.time()

    # Save all requests (both streaming and non-streaming)
    settings = get_settings()
    save_record = settings.ENABLE_QA_RECORDS
    request_body_str = body.decode("utf-8", errors="replace")

    return await _forward_chat(
        target_url, headers, body, is_stream,
        record_data={
            "user_id": user.id,
            "api_key_id": key_obj.id if key_obj else None,
            "target_model": target_model,
            "method": "POST",
            "request_body": request_body_str,
            "start_time": start_time,
            "client_ip": _get_client_ip(request),
        },
    )


@router.api_route("/v1/completions", methods=["GET", "POST"])
async def proxy_completions(request: Request, db: AsyncSession = Depends(get_db)):
    auth_header = request.headers.get("authorization")
    api_key = parse_authorization(auth_header)

    if not api_key:
        raise HTTPException(status_code=401, detail="Missing API key")

    user, key_obj = await get_user_by_api_key(api_key, db, request)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or revoked API key")

    models = await _get_user_models_from_cache(user.id, db)
    if not models:
        raise HTTPException(status_code=403, detail="No models bound to this account")

    body = await request.body()
    request_data = json.loads(body) if body else {}

    target_model = request_data.get("model", models[0].model_name)
    target = None
    for m in models:
        if m.model_name == target_model or m.id == int(target_model) if target_model.isdigit() else False:
            target = m
            break
    if not target:
        if target_model.isdigit():
            for m in models:
                if m.id == int(target_model):
                    target = m
                    break
        if not target:
            target = models[0]

    target_url = f"{target.api_url.rstrip('/')}/completions"
    headers = {
        "Authorization": f"Bearer {target.api_key}",
        "Content-Type": "application/json",
    }

    is_stream = request_data.get("stream", False)
    upstream_resp = None

    try:
        cs_session = aiohttp.ClientSession()
        upstream_resp = await cs_session.post(target_url, headers=headers, data=body,
                                              timeout=aiohttp.ClientTimeout(total=300))
        content_type = upstream_resp.headers.get("content-type", "")
        if "text/event-stream" in content_type or is_stream:
            return StreamingResponse(
                _make_stream_gen(upstream_resp, cs_session),
                status_code=upstream_resp.status,
                headers={
                    "Content-Type": "text/event-stream",
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )
        else:
            data = await upstream_resp.json()
            bg = BackgroundTasks()
            bg.add_task(_close_aiohttp, upstream_resp, cs_session)
            return JSONResponse(content=data, status_code=upstream_resp.status, background=bg)
    except aiohttp.ServerTimeoutError:
        raise HTTPException(status_code=504, detail="Upstream server timeout")
    except Exception as e:
        if upstream_resp:
            await _close_aiohttp(upstream_resp, None)
        raise HTTPException(status_code=502, detail=f"Upstream proxy error: {str(e)}")


async def _close_aiohttp(resp, session):
    """Cleanup aiohttp resources."""
    try:
        if resp and not resp.closed:
            await resp.close()
    except Exception:
        pass
    try:
        if session and not session.closed:
            await session.close()
    except Exception:
        pass


async def _forward_chat(
    target_url: str,
    headers: dict,
    body: bytes,
    is_stream: bool,
    db: Optional[AsyncSession] = None,
    record_data: Optional[dict] = None,
):
    """Forward request and return response with retry support."""
    from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

    @retry(
        stop=stop_after_attempt(2),
        wait=wait_exponential(multiplier=1, min=1, max=5),
        retry=retry_if_exception_type((aiohttp.ServerTimeoutError, ConnectionError)),
        reraise=True,
    )
    async def _do_request():
        fw_session = aiohttp.ClientSession()
        upstream_resp = await fw_session.post(
            target_url, headers=headers, data=body,
            timeout=aiohttp.ClientTimeout(total=300),
        )
        return upstream_resp, fw_session

    upstream_resp = None
    fw_session = None

    try:
        upstream_resp, fw_session = await _do_request()
        content_type = upstream_resp.headers.get("content-type", "")
        status_code = upstream_resp.status
        logger.info(f"Upstream: {status_code}, ct={content_type}, url={target_url}")

        if is_stream:
            # === Streaming path: collect all SSE lines, save after stream completes ===
            async def _collect_and_stream():
                upstream_lines = []
                try:
                    async for line in upstream_resp.content:
                        upstream_lines.append(line)
                        yield line
                except (ClientConnectionError, asyncio.TimeoutError,
                        BrokenPipeError, ConnectionResetError) as e:
                    logger.info(f"Client disconnected during stream: {type(e).__name__}")
                except OSError as e:
                    logger.info(f"Connection closed during stream: {e}")
                except GeneratorExit:
                    logger.info("Stream generator exited")
                finally:
                    # Save QA record for streaming response
                    logger.info(f"[QA Stream] record_data={record_data is not None}, lines={len(upstream_lines)}")
                    if record_data:
                        resp_body = b"".join(upstream_lines).decode("utf-8", errors="replace")
                        try:
                            request_tokens, response_tokens, total_tokens = _extract_stream_tokens(resp_body)
                        except Exception:
                            request_tokens = response_tokens = total_tokens = None
                        latency_ms = int((time.time() - record_data.get("start_time", time.time())) * 1000)
                        asyncio.create_task(
                            _save_qa_record(
                                record_data.get("user_id"),
                                record_data.get("api_key_id"),
                                record_data.get("target_model", ""),
                                record_data.get("method", "POST"),
                                record_data.get("request_body", ""),
                                resp_body,
                                status_code,
                                request_tokens,
                                response_tokens,
                                total_tokens or 0,
                                latency_ms,
                                "success",
                                record_data.get("client_ip", ""),
                            )
                        )
                    try:
                        if fw_session and not fw_session.closed:
                            await fw_session.close()
                    except Exception:
                        pass
                    try:
                        if upstream_resp and not upstream_resp.closed:
                            await upstream_resp.close()
                    except Exception:
                        pass

            return StreamingResponse(
                _collect_and_stream(),
                status_code=upstream_resp.status,
                headers={
                    "Content-Type": "text/event-stream",
                    "Cache-Control": "no-cache",
                    "Connection": "keep-alive",
                    "X-Accel-Buffering": "no",
                },
            )
        else:
            data = await upstream_resp.json()
            extra_headers = {}
            for h in ["x-request-id", "x-ratelimit-remaining-tokens", "x-ratelimit-limit-tokens"]:
                if upstream_resp.headers.get(h):
                    extra_headers[h] = upstream_resp.headers[h]

            # Extract tokens from response
            request_tokens, response_tokens, total_tokens = _extract_tokens(data)

            # Calculate latency
            latency_ms = int((time.time() - record_data.get("start_time", time.time())) * 1000) if record_data else 0

            bg = BackgroundTasks()
            bg.add_task(_close_aiohttp, upstream_resp, fw_session)

            # Save QA record in background (non-blocking, won't delay response)
            if record_data:
                bg.add_task(
                    _save_qa_record,
                    record_data.get("user_id"),
                    record_data.get("api_key_id"),
                    record_data.get("target_model", ""),
                    record_data.get("method", "POST"),
                    record_data.get("request_body", ""),
                    json.dumps(data, ensure_ascii=False),
                    status_code,
                    request_tokens,
                    response_tokens,
                    record_data.get("total_tokens", total_tokens or 0),
                    latency_ms,
                    "success",
                    record_data.get("client_ip", ""),
                )

            return JSONResponse(
                content=data, status_code=status_code,
                headers=extra_headers or None, background=bg,
            )
    except aiohttp.ServerTimeoutError:
        logger.error("Upstream timeout")
        bg = BackgroundTasks()
        if record_data:
            bg.add_task(
                _save_qa_record,
                record_data.get("user_id"),
                record_data.get("api_key_id"),
                record_data.get("target_model", ""),
                record_data.get("method", "POST"),
                record_data.get("request_body", ""),
                "",
                504,
                None,
                None,
                0,
                int((time.time() - record_data.get("start_time", time.time())) * 1000),
                "timeout",
                record_data.get("client_ip", ""),
            )
        raise HTTPException(status_code=504, detail="Upstream server timeout")
    except Exception as e:
        logger.error(f"Proxy error: {e}")
        if upstream_resp:
            await _close_aiohttp(upstream_resp, None)
        bg = BackgroundTasks()
        if record_data:
            bg.add_task(
                _save_qa_record,
                record_data.get("user_id"),
                record_data.get("api_key_id"),
                record_data.get("target_model", ""),
                record_data.get("method", "POST"),
                record_data.get("request_body", ""),
                "",
                None,
                None,
                None,
                0,
                int((time.time() - record_data.get("start_time", time.time())) * 1000),
                "error",
                record_data.get("client_ip", ""),
            )
        raise HTTPException(status_code=502, detail=f"Upstream proxy error: {str(e)}")


def _make_stream_gen(captured_resp, captured_session):
    """Create async generator with explicit variable capture at definition time.

    Uses positional argument binding to capture values at closure creation,
    avoiding late-binding closure variable issues in async code.
    """
    async def stream_chunks():
        try:
            async for chunk in captured_resp.content.iter_chunked(8192):
                if chunk:
                    yield chunk
        except (ClientConnectionError, asyncio.TimeoutError,
                BrokenPipeError, ConnectionResetError) as e:
            logger.info(f"Client disconnected during stream: {type(e).__name__}")
        except OSError as e:
            logger.info(f"Connection closed during stream: {e}")
        except GeneratorExit:
            logger.info("Generator closed")
        finally:
            await _close_aiohttp(captured_resp, captured_session)

    return stream_chunks()


@router.get("/health")
async def health_check():
    """健康检查端点，检测所有依赖服务状态。"""
    status = {"status": "ok", "timestamp": time.time(), "services": {}}

    # 检查数据库
    try:
        from app.db.session import engine as _db_engine
        if _db_engine:
            async with _db_engine.begin() as conn:
                await conn.execute(text("SELECT 1"))
            status["services"]["database"] = "healthy"
        else:
            status["status"] = "degraded"
            status["services"]["database"] = "uninitialized"
    except Exception as e:
        status["status"] = "degraded"
        status["services"]["database"] = f"unhealthy: {str(e)}"

    # 检查 Redis
    try:
        redis = await get_redis()
        await redis.ping()
        status["services"]["redis"] = "healthy"
    except Exception as e:
        status["status"] = "degraded"
        status["services"]["redis"] = f"unhealthy: {str(e)}"

    return status


@router.get("/v1/models")
async def list_models(request: Request, db: AsyncSession = Depends(get_db)):
    auth_header = request.headers.get("authorization")
    api_key = parse_authorization(auth_header)

    if not api_key:
        raise HTTPException(status_code=401, detail="Missing API key")

    user, key_obj = await get_user_by_api_key(api_key, db, request)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid or revoked API key")

    models = await _get_user_models_from_cache(user.id, db)

    items = []
    for m in models:
        items.append({
            "id": m.model_name,
            "object": "model",
            "created": int(m.created_at.timestamp()) if m.created_at else int(time.time()),
            "owned_by": "user",
        })

    return {"data": items}
