from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.db.session import get_db
from app.models.models import User
from app.schemas.user import UserCreate, UserOut, UserUpdate, UserList
from app.core.security import generate_api_key, hash_password, verify_password

router = APIRouter()


@router.get("/users", response_model=UserList)
async def list_users(
    page: int = 1,
    page_size: int = 20,
    search: str = "",
    db: AsyncSession = Depends(get_db),
):
    if search:
        count_query = select(func.count(User.id)).where(
            (User.username.like(f"%{search}%")) | (User.display_name.like(f"%{search}%"))
        )
        result = await db.execute(count_query)
        total = result.scalar() or 0
        items_query = select(User).where(
            (User.username.like(f"%{search}%")) | (User.display_name.like(f"%{search}%"))
        ).order_by(User.id.desc()).offset((page - 1) * page_size).limit(page_size)
    else:
        count_query = select(func.count(User.id))
        result = await db.execute(count_query)
        total = result.scalar() or 0
        items_query = select(User).order_by(User.id.desc()).offset((page - 1) * page_size).limit(page_size)

    result = await db.execute(items_query)
    items = result.scalars().all()
    return UserList(total=total, page=page, page_size=page_size, items=items)


@router.get("/users/{user_id}", response_model=UserOut)
async def get_user(user_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.post("/users", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def create_user(data: UserCreate, db: AsyncSession = Depends(get_db)):
    existing = await db.execute(
        select(User).where(User.username == data.username)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Username already exists")

    user = User(
        username=data.username,
        display_name=data.display_name,
        password_hash=hash_password(data.password),
        role=data.role,
        balance=data.initial_balance,
        allowed_ips=data.allowed_ips,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)

    # Generate user's API key
    api_key = generate_api_key("sk")
    from app.models.models import ApiKey
    api_key_obj = ApiKey(
        user_id=user.id,
        key=api_key,
        name=f"{user.username}'s key",
    )
    db.add(api_key_obj)
    await db.commit()
    await db.refresh(api_key_obj)

    return user


@router.put("/users/{user_id}", response_model=UserOut)
async def update_user(
    user_id: int,
    data: UserUpdate,
    db: AsyncSession = Depends(get_db),
):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        if field == "password":
            user.password_hash = hash_password(value)
        elif field == "initial_balance":
            user.balance = value
        else:
            setattr(user, field, value)

    await db.commit()
    await db.refresh(user)
    return user


@router.delete("/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(user_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    await db.delete(user)
    await db.commit()
