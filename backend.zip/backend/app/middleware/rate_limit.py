"""请求限流中间件，防止 API 滥用。"""
import time
import logging
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

logger = logging.getLogger(__name__)


class RateLimitMiddleware(BaseHTTPMiddleware):
    """基于 API Key 的 Redis 限流，支持分布式部署。"""

    def __init__(self, app, requests_per_minute: int = 60):
        super().__init__(app)
        self.requests_per_minute = requests_per_minute

    @staticmethod
    def _get_api_key(request: Request) -> str:
        """从请求中提取 API Key。"""
        auth_header = request.headers.get("authorization", "")
        if auth_header.startswith("Bearer "):
            return auth_header[7:]
        if auth_header:
            return auth_header
        return ""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        # 只对代理接口限流
        if not request.url.path.startswith("/v1/"):
            return await call_next(request)

        api_key = self._get_api_key(request)
        if not api_key:
            return await call_next(request)

        try:
            from app.db.redis import get_redis
            redis = await get_redis()
            key = f"ratelimit:{api_key}"
            window = 60  # 1 分钟窗口

            # Redis 原子操作：INCR + EXPIRE 实现滑动窗口
            current = await redis.incr(key)
            if current == 1:
                await redis.expire(key, window)

            if current > self.requests_per_minute:
                logger.warning(f"Rate limit exceeded for key: {api_key[:10]}...")
                return JSONResponse(
                    status_code=429,
                    content={
                        "detail": "Too many requests. Please retry after 1 minute.",
                        "retry_after": 60
                    },
                    headers={"Retry-After": "60"}
                )
        except Exception:
            # Redis 不可用时降级为不限流
            logger.warning("Redis unavailable for rate limiting, allowing request")
            pass

        return await call_next(request)
