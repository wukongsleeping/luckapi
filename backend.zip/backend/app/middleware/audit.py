"""请求审计日志，记录所有 API 调用用于监控和计费。"""
import time
import json
import logging
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
from starlette.requests import Request
from starlette.responses import Response

audit_logger = logging.getLogger("luckapi.audit")
audit_logger.setLevel(logging.INFO)
if not audit_logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s AUDIT [%(name)s] %(message)s')
    handler.setFormatter(formatter)
    audit_logger.addHandler(handler)


class AuditMiddleware(BaseHTTPMiddleware):
    """记录所有 API 请求的审计日志。"""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        start_time = time.time()

        # 提取关键信息
        api_key = "anonymous"
        auth_header = request.headers.get("authorization", "")
        if auth_header.startswith("Bearer "):
            api_key = auth_header[7:20] + "..."

        client_ip = request.client.host if request.client else "unknown"
        method = request.method
        path = request.url.path

        # 处理请求
        response = await call_next(request)

        # 计算耗时
        duration_ms = (time.time() - start_time) * 1000

        # 记录审计日志
        audit_logger.info(
            f"method={method} path={path} status={response.status_code} "
            f"duration={duration_ms:.1f}ms ip={client_ip} api_key={api_key}"
        )

        return response
