from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api import users, models, proxy, auth, groups, admin_models, qa
from app.middleware.body_size_limit import BodySizeLimitMiddleware
from app.middleware.rate_limit import RateLimitMiddleware
from app.middleware.audit import AuditMiddleware
from app.core.config import get_settings

settings = get_settings()

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS - 生产环境应配置具体域名
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 请求体大小限制 (10MB)
app.add_middleware(BodySizeLimitMiddleware, max_size_mb=10)

# 审计日志 (记录所有 API 请求)
app.add_middleware(AuditMiddleware)

# API 限流 (60 次/分钟)
app.add_middleware(RateLimitMiddleware, requests_per_minute=60)

# Register routers
app.include_router(users.router, prefix="/admin/api", tags=["admin-users"])
app.include_router(models.router, prefix="/admin/api", tags=["admin-models"])
app.include_router(auth.router, prefix="/admin/api/auth", tags=["admin-auth"])
app.include_router(admin_models.router, prefix="/admin/api", tags=["admin-global-models"])
app.include_router(groups.router, prefix="/admin/api", tags=["admin-groups"])
app.include_router(qa.router, prefix="/admin/api", tags=["admin-qa-records"])
app.include_router(proxy.router)  # no prefix, mounted at root
